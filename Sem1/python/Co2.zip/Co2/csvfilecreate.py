import csv
fields = ['name','branch']
rows = [ ['Nidhish','MCA'] 
         ['Abi','MCA']
         ['Anu','BCA'] ]
filename = "hello.csv"
with open(filename,w) as csvfile :
    csvwriter = csv.    
         
